# Sheetmusic Generator

![](images/after.png)

the sheetmusic generator is a plug-in for firefox made by [jen hill](http://jh-sound.com) for [RAGE thormbones](http://www.ragethormbones.rocks/)

![](images/before.png)

after installing the plug-in, simply ctrl+click or two-finger click anywhere on the desired webpage and select "Turn This Page Into Sheetmusic!"

![](images/menu.png)

from that moment on, all pages navigated to through clicking on a link will be automatically translated. to stop, ctrl+click and select "Please No More Sheetmusic!"

![](images/no-more.png)